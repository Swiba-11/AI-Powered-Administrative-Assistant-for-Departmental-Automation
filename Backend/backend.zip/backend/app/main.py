from fastapi import FastAPI
from app.api import auth, student, admin

app = FastAPI()

# Include authentication routes
app.include_router(auth.router)
app.include_router(student.router)
app.include_router(admin.router)

